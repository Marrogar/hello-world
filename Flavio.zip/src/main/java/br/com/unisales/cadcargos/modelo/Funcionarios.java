package br.com.unisales.cadcargos.modelo;

import org.dizitart.no2.IndexType;
import org.dizitart.no2.NitriteId;
import org.dizitart.no2.objects.Id;
import org.dizitart.no2.objects.Index;
import org.dizitart.no2.objects.Indices;

@Indices(value = {
        //impede que seja cadastrado funcionario com mesmo nome
        @Index(value = "nomeCargos", type = IndexType.Unique)
})
public class Funcionarios {
    @Id
    public NitriteId id;// gerado automaticamente
    private String nome;
    private String cpf;
    private String nasc;
    private String tel;
    private Cargos cargos;
    private String nomeCargos;

    public String getNome() {
        return this.nome;
    }
        public String getCPF() {
            return this.cpf;
        }
        public String getNasc(){
        return this.nasc;
    }
    public String getTel() {
        return tel;
    }

    public void setNome(String nome) {
        this.nome = nome;
        this.nomeCargos =
                (this.cargos!=null)
                        ?this.nome + ":" + this.cargos.id.getIdValue()
                        :this.nome + ":";
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setNasc(String nasc) {
        this.nasc = nasc;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public Cargos getCargos() {
        return cargos;
    }

    public void setCargos(Cargos cargos) {
        this.cargos = cargos;
        this.nomeCargos = this.nome + ":" + this.cargos.id.getIdValue();
    }

    @Override
    public String toString() {
        return this.nome + '\n' + cpf + '\n' + nasc + '\n' + tel + '\n' + "[" + cargos.nome + "]";
    }
}
