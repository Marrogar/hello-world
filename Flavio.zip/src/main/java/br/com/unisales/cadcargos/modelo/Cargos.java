package br.com.unisales.cadcargos.modelo;

import org.dizitart.no2.IndexType;
import org.dizitart.no2.NitriteId;
import org.dizitart.no2.objects.Id;
import org.dizitart.no2.objects.Index;
import org.dizitart.no2.objects.Indices;

import java.util.Objects;

@Indices(value = {
        //impede que sejam criados dois cargos com o mesmo nome
        @Index(value = "nome", type = IndexType.Unique)
})
public class Cargos {
    @Id
    public NitriteId id;// gerado automaticamente
    public String nome;

    @Override
    public String toString() {
        return this.nome;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cargos cargos = (Cargos) o;
        return Objects.equals(id, cargos.id);
    }

}