package br.com.unisales.cadcargos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import br.com.unisales.cadcargos.persistencia.BaseDados;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String nomeArquivoDB = getFilesDir().getPath() + "/baseDadosFuncionarios.db";
        BaseDados.init(nomeArquivoDB);
    }

    public void abreTelaCargos(View view) {
        startActivity(new Intent(this, CargosActivity.class));
    }

    public void abreTelaFuncionarios(View view) {
        startActivity(new Intent(this, FuncionariosActivity.class));
    }
}