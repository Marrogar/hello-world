package br.com.unisales.cadcargos;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.List;

import br.com.unisales.cadcargos.modelo.Funcionarios;
import br.com.unisales.cadcargos.modelo.Cargos;
import br.com.unisales.cadcargos.persistencia.BaseDados;

public class FuncionariosActivity extends AppCompatActivity {
    //funcionarios
    Funcionarios funcionarios = new Funcionarios();

    //componentes visuais
    EditText edtNomeFuncionarios;
    EditText edtCpf;
    EditText edtNasc;
    EditText edtTel;
    Spinner spinnerCargos;
    ListView listaViewFuncionarios;

    //componentes auxiliares
    ArrayAdapter<Cargos> adapterCargos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Cadastro de funcionários");
        setContentView(R.layout.activity_funcionarios);
        edtNomeFuncionarios = findViewById(R.id.edtNomeFuncionarios);
        edtCpf = findViewById(R.id.edtCpf);
        edtNasc = findViewById(R.id.edtNasc);
        edtTel = findViewById(R.id.edtTel);
        listaViewFuncionarios = findViewById(R.id.listaViewFuncionarios);
        spinnerCargos = findViewById(R.id.spinnerCargos);
        adapterCargos = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                BaseDados.rCargos.find().toList());
        spinnerCargos.setAdapter(adapterCargos);

    }

    public void getListaFuncionarios() {
        List<Funcionarios> lista = BaseDados.rFuncionarios.find().toList();
        final ArrayAdapter<Funcionarios> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);
        listaViewFuncionarios.setAdapter(arrayAdapter);
        listaViewFuncionarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                funcionarios = BaseDados.rFuncionarios.getById(arrayAdapter.getItem(i).id);
                edtNomeFuncionarios.setText(funcionarios.getNome());
                edtCpf.setText(funcionarios.getCPF());
                edtNasc.setText(funcionarios.getNasc());
                edtTel.setText(funcionarios.getTel());
                int pos = adapterCargos.getPosition(funcionarios.getCargos());
                spinnerCargos.setSelection(pos);
                edtNomeFuncionarios.requestFocus();
                edtCpf.requestFocus();
                edtNasc.requestFocus();
                edtTel.requestFocus();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getListaFuncionarios();
    }

    public void cancelarFuncionarios(View view) {
        this.funcionarios = new Funcionarios();
        edtNomeFuncionarios.setText("");
        edtCpf.setText("");
        edtNasc.setText("");
        edtTel.setText("");
        spinnerCargos.setSelection(0);
        edtNomeFuncionarios.requestFocus();
    }

    public void salvarFuncionarios(View view) {
        try {
            this.funcionarios.setNome("" + edtNomeFuncionarios.getText());
            this.funcionarios.setCpf("" + edtCpf.getText());
            this.funcionarios.setNasc("" + edtNasc.getText());
            this.funcionarios.setTel("" + edtTel.getText());
            this.funcionarios.setCargos((Cargos) spinnerCargos.getSelectedItem());
            if (this.funcionarios.id == null) {
                BaseDados.rFuncionarios.insert(this.funcionarios);
            } else {
                BaseDados.rFuncionarios.update(this.funcionarios);
            }
        } catch (Exception ex) {
            new AlertDialog.Builder(this)
                    .setMessage(ex.getMessage())
                    .setPositiveButton(android.R.string.yes, null)
                    .show();
        }
        this.funcionarios = new Funcionarios();
        edtNomeFuncionarios.setText("");
        edtCpf.setText("");
        edtNasc.setText("");
        edtTel.setText("");
        spinnerCargos.setSelection(0);
        getListaFuncionarios();
    }

    public void excluirFuncionarios(View view) {
        if (this.funcionarios.id != null) {
            BaseDados.rFuncionarios.remove(this.funcionarios);
        }
        this.funcionarios = new Funcionarios();
        edtNomeFuncionarios.setText("");
        edtCpf.setText("");
        edtNasc.setText("");
        edtTel.setText("");
        spinnerCargos.setSelection(0);
        getListaFuncionarios();
    }
    public void abreMenu(View view) {
       // startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
