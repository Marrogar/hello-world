package br.com.unisales.cadcargos;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import br.com.unisales.cadcargos.modelo.Cargos;
import br.com.unisales.cadcargos.persistencia.BaseDados;

public class CargosActivity extends AppCompatActivity {

    //cargos
    Cargos cargos = new Cargos();

    //componentes visuais
    EditText edtNomeCargos;
    ListView listaViewCargos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Cadastro de cargos");
        setContentView(R.layout.activity_cargos);
        edtNomeCargos = findViewById(R.id.edtNomeCargos);
        listaViewCargos = findViewById(R.id.listaViewCargos);
    }

    public void salvarCargos(View view) {
        try {
            this.cargos.nome = "" + edtNomeCargos.getText();
            if (this.cargos.id == null) {
                BaseDados.rCargos.insert(this.cargos);
            } else {
                BaseDados.rCargos.update(this.cargos);
            }
        } catch (Exception ex) {
            new AlertDialog.Builder(this)
                    .setMessage(ex.getMessage())
                    .setPositiveButton(android.R.string.yes, null)
                    .show();
        }
        this.cargos = new Cargos();
        this.edtNomeCargos.setText("");
        getListaCargos();
    }

    public void getListaCargos() {
        List<Cargos> lista = BaseDados.rCargos.find().toList();
        final ArrayAdapter<Cargos> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);
        listaViewCargos.setAdapter(arrayAdapter);
        listaViewCargos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                cargos = BaseDados.rCargos.getById(arrayAdapter.getItem(i).id);
                edtNomeCargos.setText(cargos.nome);
                edtNomeCargos.requestFocus();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        getListaCargos();
    }

    public void cancelarCargos(View view) {
        this.cargos = new Cargos();
        edtNomeCargos.setText("");
        edtNomeCargos.requestFocus();
    }

    public void excluirCargos(View view) {
        if (this.cargos.id != null) {
            BaseDados.rCargos.remove(this.cargos);
        }
        this.cargos = new Cargos();
        this.edtNomeCargos.setText("");
        getListaCargos();
    }
    public void abreMenu(View view) {
        // startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}