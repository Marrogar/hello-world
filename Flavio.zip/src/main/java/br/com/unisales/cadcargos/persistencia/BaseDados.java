package br.com.unisales.cadcargos.persistencia;

import org.dizitart.no2.Nitrite;
import org.dizitart.no2.objects.ObjectRepository;

import br.com.unisales.cadcargos.modelo.Funcionarios;
import br.com.unisales.cadcargos.modelo.Cargos;

public class BaseDados {
    public static ObjectRepository<Cargos> rCargos;
    public static ObjectRepository<Funcionarios> rFuncionarios;

    public static void init(String file) {
        Nitrite db = Nitrite.builder()
                .compressed()
                .filePath(file)
                .openOrCreate("root", "salesiano");

        rCargos = db.getRepository(Cargos.class);
        rFuncionarios = db.getRepository(Funcionarios.class);
    }
}
